<?php
global $better_array;

/**
 * Implements hook_tokens().
 */
function impact_reporttokens_tokens($type, $tokens, array $data = array(), array $options = array()){
  $replacements = array();
  $sanitize = !empty($options['sanitize']);
  $better_array = array();
  if ($type = 's') {
  	 
  	 $fscs = "WA0064";
  	 //require_once ('survey_variables.php');
    foreach($tokens as $name => $original) {
      if (isset($better_array[$name])) {
        	/** 
			  * Including this file gives us access to $better_array, which is in the format of:
			  *            [survey_variable_name] => count
			  * This is then parsed by the tokens and token_info hooks, where they are broken into
			  * [survey:survey_variable_name] as the token name. 
			  */
			  if ($better_array == null) {
				 $fscs = "WA0064";
				 require_once('survey_variables.php');
			  }
        $replacements[$original] = $better_array[$name];
      }
    }
  }
  return $replacements;
}

/**
 * Implements hook_token_info().
 */
function impact_reporttokens_token_info() {
  $fscs = "0000";
  require("db_caching.php");
  
  $types = array(
    's' => array(
      'name' => t('Survey Response'),
      'description' => t('Survey response variables'),
    ),
  );
  
  $survey = array();
  $better_array;

  foreach($better_array as $var=>$count) {
    $survey[$var] = array (
      'name' => $var,
      'description' => t('Variable count')
    );
  }

  return array(
    'types' => $types,
    'tokens' => array(
      's' => $survey
    ),
  );
}

?>
